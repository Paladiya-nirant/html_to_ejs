const main = (req, res) => {

    res.render('index');

}

const m_about = (req, res) => {

    res.render('m_about');

}

const m_contact = (req, res) => {

    res.render('m_contact');

}


module.exports = {main, m_about, m_contact};