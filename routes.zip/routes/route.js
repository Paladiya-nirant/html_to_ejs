const express = require('express');
const data = express();
const task = require('../controllers/task');

data.get('/',task.main);


module.exports = data;